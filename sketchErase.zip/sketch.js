let colors = ["black","red","orange","yellow","green","blue","purple","white"]
let y = "brushW";
let slider;
function setup() {
  createCanvas(800, 800);
  background(255);
  rect(50,0,100,35)
  slider = createSlider(1, 35, 100);
  slider.position(60,10);
  slider.style('width', '80px');
  
  
}

function draw() {
  push();
  let brushW = slider.value()
  drawButtons()
  rect(50,0,125,40)
  //designates when the line is drawn
  if (mouseIsPressed) {
    //color
    stroke(x)
    //thickness
    strokeWeight(brushW);
    //designates where the line is drawn
 line(pmouseX,pmouseY,mouseX,mouseY);
  }
  //Erases entire sketch
  if (keyIsPressed) {
    background(255); 
    rect(50,0,100,35)
  }
  pop()
}
function mousePressed() {
  
  if (mouseX>0 && mouseX<50 && mouseY>0 && mouseY<35) { 
    x = "black"
    y = "brushW"}
  
  if (mouseX>0 && mouseX<50 && mouseY>35 && mouseY<70) { 
    x = "red"
    y = "brushW"}
  
  if (mouseX>0 && mouseX<50 && mouseY>70 & mouseY<105) { 
    x = "orange"
    y = "brushW"}
  
  if (mouseX>0 && mouseX<50 && mouseY>105 && mouseY<140) {
    x = "yellow"
    y = "brushW"}
  
  if (mouseX>0 && mouseX<50 && mouseY>140 && mouseY<175) {
    x = "green" 
    y = "brushW"}
  
  if (mouseX>0 && mouseX<50 && mouseY>175 && mouseY<210) {
    x = "blue" 
    y = "brushW"}
  
  if (mouseX>0 && mouseX<50 && mouseY>210 && mouseY<245) {
    x = "purple" 
    y = "brushW"}
  
  if (mouseX>0 && mouseX<50 && mouseY>245 && mouseY<280) {
  x = "white"
  y = "brushW"}
  
  }
function drawButtons() {
  for(let i = 0; i<8; i++) {
  fill(colors[i])
  rect(0,i * 35,50,35)
  }
}
