let numbers = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20']
let d20;
let Result;
let Toss;
let letsRoll; 

function preload(){
  Result = loadImage("d20Sketch/pictures/dice.png");
  Toss = loadImage("d20Sketch/pictures/rollimg1.jpeg");
}

function setup() {
  createCanvas(800, 800);
  background(255);
  d20 = new Die(400,400,400,Result,Toss);

}

function mouseClicked() {
  background(255);
  d20.display();
  d20.roll();
  textSize(45)
   text(random(numbers),380,410);
  
}


class Die {
  constructor(x,y,size,Result,Toss) {
  this.x = x;
  this.y = y;
  this.size = size; 
  this.number = Result;
  this.Result = Result;
  this.Toss = Toss; } 
  
  display() {
    push();
    imageMode(CENTER);
    image(this.number,this.x,this.y,this.size,this.size);
    pop(); }
  
  roll() {
    if (random() < 0.5) { 
      this.number = this.Result;
    }
    else {this.number = this.Toss; }
    }
}

