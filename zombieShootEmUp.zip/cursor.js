class Cursor { 
  constructor(x,y,size,picture) { 
    this.x = x;
    this.y = y;
    this.size = size;
    this.picture = cursorImg;
  }
  display() {
    push();
    imageMode(CENTER);
    image(this.picture, this.x, this.y, this.size, this.size);
    pop(); 
  } 
}