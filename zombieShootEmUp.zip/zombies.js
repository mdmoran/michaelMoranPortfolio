class Jitter {
  constructor(x,y) {
    this.x = x;
    this.y = y;
    this.diameter = 50;
    this.speed = random(0.1,0.8);
    this.picture = jitterImg;
  }

  move() {
    this.x += random(-this.speed, this.speed);
    this.y += this.speed;
  }

  display() {
    push();
    imageMode(CENTER);
    image(this.picture,this.x,this.y,this.diameter,this.diameter)
    pop();
  }
}