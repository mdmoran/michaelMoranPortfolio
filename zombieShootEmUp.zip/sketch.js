let gameScreen = 0;
let bullets = [];
let cursorImg;
let jitterImg;
let bugs = [];

function preload() {
  cursorImg = loadImage("cursor.png");
  jitterImg = loadImage("zombies.png"); }

function setup() {
  createCanvas(800, 400);
  cursorImg = new Cursor(0,height-20,50,cursor.png);
}

function draw() {
  
  print(gameScreen);
  background(255);
    for (let i=bullets.length-1; i>=0; i--) {
  bullets[i].move();
  bullets[i].display();
    if(bullets[i].y < 0) { 
    bullets.splice(i,1); } 
  }
  
  if (gameScreen === 0) { 
      initScreen(); 
  }  else if (gameScreen === 99) {
      gameOverScreen(); 
  }  else if (gameScreen >= 1) { 
      gamePlayScreen(); 
  }  
}
function initScreen() {
  background(255);
  textSize(32);
  text("Zombie Shoot 'Em Up",230,200);
  textSize(25);
  text("Click Anywhere to Start Shootin'",210, 250);}

function gamePlayScreen() {
  background("green");
  rectMode(CENTER);
  fill("tan");
  rect(400,200,100,height);
  cursorImg.display();
  cursorImg.x = mouseX;
  for (let i=bullets.length-1; i>=0; i--) {
  bullets[i].move();
  bullets[i].display();
    if(bullets[i].y < 0) { 
   bullets.splice(i,1); }
   }
  for(let i=bugs.length-1; i>=0; i--) {
  bugs[i].move();
  bugs[i].display(); 
   if (bugs[i].y >= height) { 
     gameScreen=99 }
  for (let j=0; j<bullets.length; j++) {
  if (bullets[j].intersect(bugs[i])) { 
    bugs.splice(i,1);
    bullets.splice(j,1);
    break; }
    }
  }
  if (bugs.length === 0 && gameScreen >= 1) { 
      levelScreen();}
}
  
function gameOverScreen() {
  gameScreen = 99;
  background("red");
  fill("black");
  text("Game Over",325,200);
  }
  
function mousePressed() { 
  if (gameScreen === 0 || bugs.length === 0) { 
    startGame(); 
    } else if (gameScreen > 0) { 
      bullets.push(new Bullet(mouseX,height-20));
   }  else if (gameScreen === 99) {
       bugs.splice(i,bugs[i].length);
       gameScreen = 0;
       initScreen(); }
  
  function startGame() { 
  gameScreen = (gameScreen + 1);
  for (let i=0; i<(6 * gameScreen); i++) { 
    bugs.push(new Jitter(random(width),0))}}
}

function levelScreen() {
 background(0);
  fill("white");
  textSize(32);
  text("Level Complete",290,200);
  textSize(25);
  text("Click Anywhere to Start Next Level",210, 250); }






